fun main() {
    var x = 1
    var y = 2
    //usage of expression ${x+y}
    println("x+y=${x + y}")

    if (true) {
        println("${x++}")
    } else {
        println("${++x}")
    }

    //when expression
    //useful as in alternative for if-else
    val m = 20
    val text = when (m) {
        in 10..20 -> {
            x += 1
            "message 1"
            x += 1
            //inside the block, only the last statement line is assigned to the variable
        }

        10, 20, 30, 40 -> "message 2"
        else -> "message 3"
    }
    println(text)
    println("$x")

    //another operator
    if(m in 10..20)   {
        println("in range")
    }

    //dealing with null, checks and precautions when declared as null
    var z: String? = null
    println(z?.length)  //graceful handling
    println(z!!.length) //throws null pointer exception from java

    //ternary operator doesn't work here as in java
}