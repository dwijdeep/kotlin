//without constructor
class Boy()   {
    var name = ""
    var curlyHair = true
    var age = 0

    fun crawl() {
        println("${name} is crawling")
    }

    fun walk()  {
        println("${name} is walking")
    }

    fun run()   {
        println("${name} is running")
    }
}

//with primary constructor
//way 1
//use this when some operation is needed before actually using the parameters
class Boys(nam: String, crlyHair: Boolean, ag: Int) {
    var name = nam.trim().lowercase()
    var curlyHair = crlyHair
    var age = ag

    fun crawl() {
        println("$name are crawling")
    }

    fun walk()  {
        println("$name are walking")
    }

    fun run()   {
        println("$name are running")
    }
}

//way 2
//use this when we intend to use the same parameters as declared in main()
class DesiBoys(var name: String, var curlyHair: Boolean, var age: Int) {

    fun crawl() {
        println("$name - desi boy is crawling")
    }

    fun walk()  {
        println("$name - desi boy is walking")
    }

    fun run()   {
        println("$name - desi boy is running")
    }
}