fun main()  {
    //statically typed language
    var name : String = "Deepak"
    //kotlin is type inference, so
    var nameAnother = "Singh"
    var age : Int = 23
    var byte : Byte = 127
    //if type inference is not used, javaClass return int, highest data type
    println("Hello $nameAnother having age $age")
    var short : Short = 32000
    //to know the data type
    println(short.javaClass)

    //other data types are long, float, double, char, boolean etc, same as in java
    // max, min length is same as of java var

    //two types of variables in kotlin
    //val acts like final, can't be reassigned
    val char = 'A'
    //var's value can be reassigned
    var bool = true
    //ways to print a variable
    println(char)
    println("$bool")
}