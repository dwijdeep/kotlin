fun main() {
    //for loops
    //1.

    for(i in 1..10) {
        print(i)
    }

    println()
    //2.
    for(i in 1 until 10) {
        print(i)
    }

    println()
    //3.
    for (i in 10 downTo 1 step 5)  {
        print(i)
    }

    println()
    //4.
    fun sum(vararg nums: Int): Int {
        var sum = 0
        // shorthand
        // xs.sum()
        nums.forEach {
            sum+=it
        }
        return sum
    }
    val zeroNumbers = sum(1,2,3,4,5)
    print(zeroNumbers)
}