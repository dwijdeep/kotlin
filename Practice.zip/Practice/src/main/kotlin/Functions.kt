fun main()  {
    //sayHi("deepak", 21)
    //println(returnVar(5))

    println(boloHello("sunny",replaceArgument()))
    //order can also be changed by using the exact arguments names defined in the method
    println(boloHello(string2 = "hola", string1 = "sunny"))
}

fun sayHi(name : String, age : Int) {
    //function parameters are defined as val scope, it's value will never change
    println("My name is $name and my age is $age.")
    //but it can be changed by declaring another var with same name 'age'
    var age = 20
    println("My name is $name and my age is $age.")
}

fun returnVar(smallInt: Int): String    {
    return "Hello Mr. $smallInt"
}

//default values can be assigned to a func
//if string2 is not present "" will be taken, else exact argument from the calling function will be provided
fun boloHello(string1 : String, string2: String = ""): String   {
    return "Hii $string1, message for you is $string2!"
}

fun replaceArgument() = "no message provided"