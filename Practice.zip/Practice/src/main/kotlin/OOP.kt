fun main()  {
    val boy1 = Boy()
    boy1.name = "Elon"
    boy1.curlyHair = false
    boy1.age = 42

    println("name = ${boy1.name}")
    println("does he have curly hair? = ${boy1.curlyHair}")
    println("age = ${boy1.age}")

    boy1.crawl()
    boy1.walk()
    boy1.run()

    println("**************************")

    val boys = Boys("     Chetan",true,24)
    println("name = ${boys.name}")
    println("does he have curly hair? = ${boys.curlyHair}")
    println("age = ${boys.age}")

    boys.crawl()
    boys.walk()
    boys.run()

    println("**************************")

    val boys1 = Boys("Hiren",false, 35)
    println("name = ${boys1.name}")
    println("does he have curly hair? = ${boys1.curlyHair}")
    println("age = ${boys1.age}")

    boys1.crawl()
    boys1.walk()
    boys1.run()

    println("**************************")

    val boy2 = DesiBoys("Dhillon",false,12)
    println("name = ${boy2.name}")
    println("does he have curly hair? = ${boy2.curlyHair}")
    println("age = ${boy2.age}")

    boy2.crawl()
    boy2.walk()
    boy2.run()

}