fun main()   {
    val names: Array<String> = arrayOf("Deepak","Deepak","Meer")
    //val names = arrayOf("Deepak","Deepak","Meer")
    //array can be homogeneous and heterogeneous
    println(names.size)
}